﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class ConverterScript : MonoBehaviour
{
    float SGDUSD = 0.74f;
    float SGDJPY = 82.78f;
    float SGDRM = 3.08f;
    float SGDEUR = 0.63f;
    float SGDKRW = 881.54f;
    float SGDTWD = 20.73f;

    public Toggle toggleUSDollar;
    public Toggle toggleJPYen;
    public Toggle toggleRMRinggit;
    public Toggle toggleEUREuro;
    public Toggle toggleKRWWon;
    public Toggle toggleTWDollar;

    public InputField inputConvertedAmount;
    public InputField inputAmount;

    float totalAmount;

    public Text debugText;

    public float amount;

    // Start is called before the first frame update
    void Start()
    {
        toggleUSDollar.isOn = false;
        toggleJPYen.isOn = false;
        toggleRMRinggit.isOn = false;
        toggleEUREuro.isOn = false;
        toggleKRWWon.isOn = false;
        toggleTWDollar.isOn = false;
      
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void btnConvert_Click()
    {
        try
        {
            float amount = float.Parse(inputAmount.text);

            if (toggleUSDollar.isOn == true)
            {
                totalAmount = Mathf.Round((amount / SGDUSD) * 100f) / 100f;
                inputConvertedAmount.GetComponent<InputField>().text = "$" + (totalAmount);
            }

            else if (toggleJPYen.isOn == true)
            {
                inputConvertedAmount.GetComponent<InputField>().text = (amount * SGDJPY) + " Yen";
            }

            else if (toggleRMRinggit.isOn == true)
            {
                inputConvertedAmount.GetComponent<InputField>().text = (amount * SGDRM) + " Ringgit";
            }

            else if (toggleEUREuro.isOn == true)
            {
                inputConvertedAmount.GetComponent<InputField>().text = (amount * SGDEUR) + " Euro";
            }

            else if (toggleKRWWon.isOn == true)
            {
                inputConvertedAmount.GetComponent<InputField>().text = (amount * SGDKRW) + " Won";
            }

            else if (toggleTWDollar.isOn == true)
            {
                inputConvertedAmount.GetComponent<InputField>().text = (amount * SGDTWD) + " TW Dollars";
            }

            else
            {
                debugText.text = "Please input in the currency.";
            }
        }    
         catch (FormatException)
        {
            debugText.text = "Please input in the amount.";
        }
    }

    public void btnClear_Click()
    {
        toggleUSDollar.isOn = false;
        toggleJPYen.isOn = false;
        toggleRMRinggit.isOn = false;
        toggleEUREuro.isOn = false;
        toggleKRWWon.isOn = false;
        toggleTWDollar.isOn = false;

        inputConvertedAmount.text = "";
        inputAmount.text = "";
        debugText.text = "";
    }
}
